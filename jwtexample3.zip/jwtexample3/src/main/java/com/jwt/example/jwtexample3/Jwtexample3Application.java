package com.jwt.example.jwtexample3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jwtexample3Application {

	public static void main(String[] args) {
		SpringApplication.run(Jwtexample3Application.class, args);
	}

}
