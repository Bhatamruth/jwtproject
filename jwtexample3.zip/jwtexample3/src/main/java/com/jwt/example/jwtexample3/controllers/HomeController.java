package com.jwt.example.jwtexample3.controllers;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jwt.example.jwtexample3.models.User;
import com.jwt.example.jwtexample3.services.UserService;

@RestController
@RequestMapping("/home")
public class HomeController {
	@Autowired
	private UserService  userService;

	// http://localhost:9091/home/users
	@GetMapping("/users")
	public List<User> getuser()
	{
		System.out.println("getting user");
		return userService.getUser();
		
	}
	
	@GetMapping("/current-users")
	public String getLoggedInUser(Principal principal) {
		return principal.getName();
	}
	
}
